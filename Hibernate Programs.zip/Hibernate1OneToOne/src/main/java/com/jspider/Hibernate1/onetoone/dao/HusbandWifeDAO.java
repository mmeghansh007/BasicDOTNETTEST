package com.jspider.Hibernate1.onetoone.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


import org.hibernate.TransactionException;

import com.jspider.Hibernate1.onetoone.dto.HusbandDTO;
import com.jspider.Hibernate1.onetoone.dto.WifeDTO;

public class HusbandWifeDAO {

	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	private static void openConnection() {
		factory = Persistence.createEntityManagerFactory("OneToOne");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnection() {
		if (factory != null) {
			factory.close();

		}
		if (manager != null) {
			manager.close();
		}
		try {
			transaction.rollback();
		} catch (TransactionException e) {
			System.out.println("Transaction is committed.");
		}

	}

	public static void main(String[] args) {
		try {

			openConnection();
			transaction.begin();

			WifeDTO wife = new WifeDTO();
			wife.setId(3);
			wife.setName("Karina");
			wife.setEmail("karina@vk.com");
			wife.setContact(942454657L);
			wife.setAge(30);

			

			HusbandDTO husband = new HusbandDTO();
			husband.setId(3);
			husband.setName("Virat K");
			husband.setEmail("viratkohli@vk.com");
			husband.setContact(942027969L);
			husband.setAge(30);
			

			husband.setWife(wife);
			//wife.setHusband(husband);
			manager.persist(husband);
			manager.persist(wife);
			

			transaction.commit();

		} finally {

			closeConnection();
		}

	}

}
