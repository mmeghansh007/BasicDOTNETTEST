package com.jspider.Hibernate1.onetoone.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import jakarta.persistence.OneToOne;
import lombok.Data;

@Entity
@Data
public class WifeDTO {

	@Id
	private int id;
	private String name;
	private String email;
	private long contact;
	private int age;
	
//	@OneToOne
//	private HusbandDTO husband;
//	
//	
}

	

