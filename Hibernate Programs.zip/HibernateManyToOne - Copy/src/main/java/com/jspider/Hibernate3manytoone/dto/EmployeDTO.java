package com.jspider.Hibernate3manytoone.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;
@Entity
@Data
public class EmployeDTO {
	
	@Id
	private int id;
	private String name;
	private String email;
	private int salary;
	
	@ManyToOne
	private CompanyDTO company;
	
	
	

}
