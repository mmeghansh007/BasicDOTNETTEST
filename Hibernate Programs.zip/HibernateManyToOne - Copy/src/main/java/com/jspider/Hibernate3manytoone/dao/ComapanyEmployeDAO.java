package com.jspider.Hibernate3manytoone.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.TransactionException;

import com.jspider.Hibernate3manytoone.dto.CompanyDTO;
import com.jspider.Hibernate3manytoone.dto.EmployeDTO;

public class ComapanyEmployeDAO {

	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	public static void openConnection() {
		factory = Persistence.createEntityManagerFactory("ManyToOne");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnection() {
		if (factory != null) {
			factory.close();

		}
		if (manager != null) {
			manager.close();
		}
		try {
			transaction.rollback();
		} catch (TransactionException e) {
			System.out.println("Transaction is committed.");
		}

	}

	public static void main(String[] args) {
		try {

			openConnection();
			transaction.begin();

			CompanyDTO company = new CompanyDTO();
			company.setId(1);
			company.setName("Accenture");
			company.setCity("PUNE");

			manager.persist(company);

			EmployeDTO employe = new EmployeDTO();
			employe.setId(1);
			employe.setName("Meghansh m");
			employe.setEmail("meghamshmamidi@gmail.com");
			employe.setSalary(150);
			employe.setCompany(company);

			manager.persist(employe);

			EmployeDTO employe1 = new EmployeDTO();
			employe1.setId(2);
			employe1.setName("Mintu");
			employe1.setEmail("Mintu@gmail.com");
			employe1.setSalary(400);
			employe1.setCompany(company);

			manager.persist(employe1);

			transaction.commit();

		} finally {
			closeConnection();
		}
	}

}
